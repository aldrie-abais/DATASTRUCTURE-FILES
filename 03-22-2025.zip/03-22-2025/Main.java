public class Main
{
	public static void main(String[] args)
	{
		MySinglyLinkedList list = new MySinglyLinkedList();
		list.add(5);
		list.add(8);
		list.add("A");
		list.add(5);
		list.add("A");
		list.add(9);
		System.out.println("Original List");
		System.out.println(list);
		System.out.printf("\nNode: %S\n",list.getByLocation(1));

        list.edit(9, 10);
        System.out.println(list);

		list.editByLocation(1, "AA");
		System.out.println(list);
		
		list.insert(1, "000");
		System.out.println(list);

        list.deleteAll();
        System.out.println("After Deletion:");
		System.out.println(list);
        
	}
}