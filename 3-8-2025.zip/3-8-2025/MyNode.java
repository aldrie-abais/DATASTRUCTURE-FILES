public class MyNode 
{
   Object item;
   MyNode next;
}