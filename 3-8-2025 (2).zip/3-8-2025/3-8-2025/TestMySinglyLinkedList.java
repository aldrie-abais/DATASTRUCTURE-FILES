public class TestMySinglyLinkedList 
{
   public static void main(String[] args)
   {
      MySinglyLinkedList list = new MySinglyLinkedList();
      list.add(5);
      list.add(8);
      list.add(2);
      list.add(5);
      System.out.println("Original List");
      System.out.println(list);
      System.out.printf("\nNode: %S\n",list.getByLocation(1));
      
      list.edit(8, 4);
      System.out.println("\nList after 8 is replaced by 4");
      System.out.println(list);
   }
}