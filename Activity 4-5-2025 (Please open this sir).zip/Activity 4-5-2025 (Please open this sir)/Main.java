import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
            StackNode SN = new StackNode();
            Scanner in = new Scanner(System.in);

            boolean Anchor1 = false;
            boolean checker = false;
            int choice = 0;
            while(!Anchor1){
                do{
                    try{
                        System.out.println("\n==========PARENTHESES CHECKER==========\n");
                        System.out.println("========\n");
                        System.out.println(" Menu:\n");
                        System.out.println("1.Start\n");
                        System.out.println("2.Exit\n");

                        checker = false;
                        System.out.print("Choose(1-2): ");
                        choice = in.nextInt();
                    }catch(Exception e){
                        checker = true;
                        System.out.println("Enter 1-2 only!");
                        in.next();
                    }
                }while(checker);


                if(choice == 1)
                {
                    Start(in);
                }
                else if(choice == 2){
                    Anchor1 = true;
                }else{
                    System.out.println("Enter 1-2 only!");
                }
            };
        }
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        public static void Start(Scanner in){

            boolean checker = false;

            StackNode SN = new StackNode();
            boolean Anchor2 = false;
            while(!Anchor2){

                boolean checker2 = false;

                String[] Options = {
                        "1.Input",
                        "2.Output",
                        "3. Back"
                };

                int choice = 0;
                checker2 = false;
                do{
                    try{
                        checker2 = false;
                        System.out.println("\n\nSub Menu:");
                        for(int i = 0; i < 3; i = i + 1){
                            System.out.println(Options[i]);
                        }

                        System.out.print("\n\nChoose(1-3): ");
                        choice = in.nextInt();
                        // 		in.nextLine();
                    }catch(Exception e){
                        checker2 = true;
                        System.out.println("Enter 1-3 only!");
                        in.next();
                        in.nextLine();
                    }
                }while(checker2);


                switch(choice){
                    case 1:
                        in.nextLine();
                        System.out.print("Input: ");
                        String equation = in.nextLine();

                        String[] equationArr = new String[equation.length()];

                        for (int i = 0; i < equation.length(); i++) {
                            equationArr[i] = String.valueOf(equation.charAt(i));
                            SN.push(equationArr[i]);
                        }

                        SN.perform();

                        break;

                    case 2:


                        System.out.println(SN);

                        break;

                    case 3:
                        Anchor2 = true;
                        break;
                }
            }
        }

    }

