class MyNode{
    Object item;
    MyNode next;
    public MyNode(Object item){
        this.item = item;
    }
    
}