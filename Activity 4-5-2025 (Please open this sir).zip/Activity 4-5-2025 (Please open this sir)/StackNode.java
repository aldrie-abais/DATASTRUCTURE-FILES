import java.util.Scanner;

class StackNode {
    MyNode top;
    int count;

    public StackNode() {
        top = null;
        count = 0;
    }

    public boolean isFull() {
        return false;
    }

    public boolean isEmpty() {
        return top == null;
    }

    public boolean push(Object i) {
        MyNode newNode = new MyNode(i);
        if (isEmpty()) {
            top = newNode;
        } else {
            MyNode tempTop = top;
            while (tempTop.next != null) {
                tempTop = tempTop.next;
            }
            tempTop.next = newNode;
        }
        count++;
        return true;
    }

    public Object peek() {
        if (!isEmpty()) {
            MyNode tempTop = top;
            while (tempTop.next != null) {
                tempTop = tempTop.next;
            }
            return tempTop.item.toString();
        }
        return null;
    }

    public boolean pop() {
        if (!isEmpty()) {
            MyNode tempTop = top;
            MyNode previousTop = null;
            while (tempTop.next != null) {
                previousTop = tempTop;
                tempTop = tempTop.next;
            }
            if(previousTop != null) {
                previousTop.next = null;
            }

            return true;
        }
        count--;
        return false;
    }

    public String toString() {
        String result = "";
        if (!isEmpty()) {
            MyNode tempTop = top;


            while (tempTop.next != null) {
                tempTop = tempTop.next;
            }
            result += "[" + tempTop.item + "]\n";

            while (tempTop != top) {
                MyNode tempTop2 = top;
                while (tempTop2.next != tempTop) {
                    tempTop2 = tempTop2.next;
                }
                tempTop = tempTop2;
                result += "[" + tempTop.item + "]\n";
            }
        }
        return result;
    }

    public void perform(){

        int OpenP = 0;
        int CloseP = 0;
        
        if (!isEmpty()) {
            MyNode tempTop = top;

            if("(".equals(tempTop.item.toString())) {
                while (tempTop.next != null) {
                    if (tempTop.item.toString().equals("(")) {
                        OpenP++;
                    } else if (tempTop.item.toString().equals(")")) {
                        CloseP++;
                    }
                    tempTop = tempTop.next;
                }
                if (tempTop.item.toString().equals("(")) {
                    OpenP++;
                } else if (tempTop.item.toString().equals(")")) {
                    CloseP++;
                }
            }else {
                System.out.println("Must start with an open parenthesis.");

            }
            while (tempTop.next != null) {

                if (tempTop.item.toString().equals("(")) {


                }

                tempTop = tempTop.next;
            }

                if(OpenP == CloseP){
                    System.out.println("Balance.");

                }else{
                    System.out.println("Not Balance.");
                }
        }else{
            System.out.println("No Parentheses found.");
        }
    }

}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

